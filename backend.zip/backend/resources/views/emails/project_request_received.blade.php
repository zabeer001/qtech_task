<h2>New Project Request</h2>

<p><strong>Name:</strong> {{ $projectRequest->name }}</p>
<p><strong>Email:</strong> {{ $projectRequest->email_address }}</p>
<p><strong>Phone:</strong> {{ $projectRequest->phone_number }}</p>
<p><strong>Company:</strong> {{ $projectRequest->company_name }}</p>
<p><strong>Service Type:</strong> {{ $projectRequest->type_of_service }}</p>
<p><strong>Project Description:</strong> {{ $projectRequest->project_description }}</p>

<p>Thank you!</p>